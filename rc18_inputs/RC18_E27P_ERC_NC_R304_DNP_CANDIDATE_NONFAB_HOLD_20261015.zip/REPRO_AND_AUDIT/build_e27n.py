#!/usr/bin/env python3
"""Static non-fabrication KiCad symbol electrical type sync. Not a native KiCad validation."""
import csv, io, json, hashlib, re, zipfile, pathlib, shutil
from collections import Counter
ROOT=pathlib.Path('/mnt/data/rc18_e27n')
SRC=pathlib.Path('/mnt/data/rc18_e27m_sources/RC18_E26L_GRID_GEOMETRY_PARITY_NONFAB_HOLD_20261015.zip')
ECO=pathlib.Path('/mnt/data/rc18_arch_rethink_sources/RC18_E26Y_PIN_TYPES_FAILSAFE_RECONCILED_NONFAB_HOLD_20261015.zip')
REQ=pathlib.Path('/mnt/data/rc18_e27m_sources/E25M_REQUIREMENT_TRACEABILITY_MASTER.csv')
STOP=pathlib.Path('/mnt/data/rc18_e27m_sources/E25R_RELEASE_BLOCKERS.csv')
OUT=ROOT/'RC18_E27N_KICAD_CANDIDATE_NOT_FAB'
shutil.rmtree(OUT,ignore_errors=True); OUT.mkdir(parents=True)
sha=lambda b:hashlib.sha256(b).hexdigest()
# Verify source original file manifest before touching any member.
with zipfile.ZipFile(SRC) as z:
 top='RC18_E26L_GRID_GEOMETRY_NONFAB_HOLD/'
 members={n[len(top):]:z.read(n) for n in z.namelist() if n.startswith(top) and not n.endswith('/')}
expected={n.strip():h for h,n in (line.split('  ',1) for line in members['MANIFEST_SHA256.txt'].decode().splitlines() if '  ' in line)}
assert len(expected)==40 and all(sha(members[k])==v for k,v in expected.items()), 'Original manifest did not verify'
with zipfile.ZipFile(ECO) as z:
 rows=list(csv.DictReader(io.StringIO(z.read('E26Y_20261015/E26X_17PIN_TYPE_ECO_PROPOSAL.csv').decode('utf-8-sig'))))
assert len(rows)==17
changes={(r['symbol'],r['pin_number']):(r['old_type'],r['candidate_type']) for r in rows}
assert len(changes)==17
# Return matching balanced S-expression to constrain editing to a selected cached symbol or library symbol.
def sexpr_end(text,start):
 depth=0; in_str=False; escape=False
 for i in range(start,len(text)):
  c=text[i]
  if in_str:
   if escape:escape=False
   elif c=='\\':escape=True
   elif c=='"':in_str=False
   continue
  if c=='"':in_str=True
  elif c=='(':depth+=1
  elif c==')':
   depth-=1
   if depth==0:return i+1
 raise ValueError('unterminated s-expression')

def patch_symbol(blob,symname):
 """Only pin type tokens within matching name symbol; validate pin number and old type."""
 starts=list(re.finditer(r'\(symbol "'+re.escape(symname)+r'"',blob))
 assert len(starts)==1,(symname,len(starts))
 m=starts[0]; end=sexpr_end(blob,m.start()); section=blob[m.start():end]
 found=[]; edits=[]
 for pm in re.finditer(r'\(pin (?P<type>[a-z_]+) line\b',section):
  pin_start=pm.start(); pin_end=sexpr_end(section,pin_start)
  pin_block=section[pin_start:pin_end]
  num_match=re.search(r'\(number "(\d+)"',pin_block)
  if not num_match:continue
  number=num_match.group(1)
  key=(symname.split(':')[-1],number)
  if key in changes:
   old,new=changes[key]
   assert pm.group('type')==old,(symname,number,pm.group('type'),old)
   edits.append((pm.start('type'),pm.end('type'),new,number,old))
   found.append(number)
 assert len(found)==sum(1 for key in changes if key[0]==symname.split(':')[-1]),(symname,found)
 for a,b,new,num,old in sorted(edits,reverse=True):section=section[:a]+new+section[b:]
 return blob[:m.start()]+section+blob[end:],[(symname,n,old,new) for a,b,new,n,old in edits]

modified_files=['RC18_E25C.kicad_sym','11_INDEPENDENT_FAULT_LATCH_E25C.kicad_sch']
evidence=[]
for name in modified_files:
 old_text=members[name].decode('utf-8');new_text=old_text
 for sym in ['IC_U1001','IC_U1003','IC_U1005']:
  fullname=('RC18_E25C:' if name.endswith('.kicad_sch') else '')+sym
  new_text,entries=patch_symbol(new_text,fullname)
  evidence.extend([(name,)+e for e in entries])
 assert new_text!=old_text
 # Changes reverseable by applying exact changes in reverse without changing anything else.
 test=new_text
 for sym in ['IC_U1001','IC_U1003','IC_U1005']:
  before_sym=('RC18_E25C:' if name.endswith('.kicad_sch') else '')+sym
  # For strict reversibility, token-local regex count enforces that nothing but pin types changed.
 # Keyed normalized diff in static audit below.
 members[name]=new_text.encode('utf-8')
assert len(evidence)==34
# Revert changed type tokens with same symbolic spans, confirm full original bytes equal.
def reverse_one(t,name):
 for sym in ['IC_U1001','IC_U1003','IC_U1005']:
  fname=('RC18_E25C:' if name.endswith('.kicad_sch') else '')+sym
  matches=list(re.finditer(r'\(symbol "'+re.escape(fname)+r'"',t));assert len(matches)==1
  st=matches[0].start();en=sexpr_end(t,st);sect=t[st:en]
  es=[]
  for m in re.finditer(r'\(pin ([a-z_]+) line\b',sect):
   b=sect[m.start():sexpr_end(sect,m.start())]; nm=re.search(r'\(number "(\d+)"',b)
   if nm and (sym,nm.group(1)) in changes:
    old,new=changes[(sym,nm.group(1))];assert m.group(1)==new
    es.append((m.start(1),m.end(1),old))
  for a,b,old in sorted(es,reverse=True):sect=sect[:a]+old+sect[b:]
  t=t[:st]+sect+t[en:]
 return t
with zipfile.ZipFile(SRC) as z:
 for name in modified_files:
  assert reverse_one(members[name].decode(),name).encode()==z.read(top+name)
# Original manifest retained as E26L evidence separately; new manifest covers all project files.
original_manifest=members.pop('MANIFEST_SHA256.txt')
for n,b in members.items():
 p=OUT/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
(OUT/'E26L_SOURCE_MANIFEST_SHA256_LEGACY.txt').write_bytes(original_manifest)
manifest=''.join(f'{sha((OUT/n).read_bytes())}  {n}\n' for n in sorted(members))
(OUT/'MANIFEST_SHA256.txt').write_text(manifest,encoding='utf-8')
assert len(members)==40 and all(sha((OUT/n).read_bytes())==h for h,n in (line.split('  ',1) for line in manifest.splitlines()))
# Verify unaffected KiCad native sources unchanged and PCB digest unchanged.
with zipfile.ZipFile(SRC) as z:
 assert all(sha((OUT/n).read_bytes())==sha(z.read(top+n)) for n in members if n not in modified_files)
 pcb_sha=sha((OUT/'RC18_RevB_SI.kicad_pcb').read_bytes())
 assert pcb_sha=='33bc7076c529ee933e1f4d2752a047feea0c6cf0acbd086214b7c1eeed0f8b93'
# Count 64 missing and group sheets.
missing=list(csv.DictReader(io.StringIO((OUT/'E26L_MISSING_64_FIT_PARTS.csv').read_text(encoding='utf-8-sig'))))
print('missing header:',list(missing[0]));print('first row',missing[0]);print('total',len(missing))
# Older E25R is the frozen release board status. This isn't closing any of the 17 blockers.
assert sum(1 for _ in csv.DictReader(open(STOP,encoding='utf-8-sig')))==17
assert sum(1 for _ in csv.DictReader(open(REQ,encoding='utf-8-sig')))==41
with open(ROOT/'E27N_APPLIED_PIN_TYPES.csv','w',newline='',encoding='utf-8-sig') as f:
 w=csv.writer(f);w.writerow(['file','symbol','pin','prior_type','candidate_type','static_test','native_erc'])
 for file,sym,num,old,new in sorted(evidence):w.writerow([file,sym,num,old,new,'EXACT_REVERSIBLE_PATCH','NOT_RUN'])
result={
 'stage':'E27N','mode':'NONFAB_KICAD_CANDIDATE','source_zip_sha256':sha(SRC.read_bytes()),
 'proposal_zip_sha256':sha(ECO.read_bytes()),'requirements_sha256':sha(REQ.read_bytes()),'blockers_sha256':sha(STOP.read_bytes()),
 'source_manifest_checked':40,'source_manifest_failures':0,'project_manifest_checked':40,'project_manifest_failures':0,
 'pin_electrical_type_changes':17,'cached_sheet_changes':17,'library_changes':17,'total_text_token_changes':34,
 'changed_files':modified_files,'unchanged_original_native_files':38,'pcb_sha256_unchanged':pcb_sha,
 'release_blockers_prior':17,'release_blockers_remaining':17,'release_blockers_closed':0,
 'native_erc_drc_parity':'NOT_RUN', 'pre_verified_output_driver':'NOT_IMPLEMENTED',
 'known_pcb_missing_fit':64,'unverified_footprints':['U1003','U1005','U1302'],
 'safety':'HOLD_NO_POWER_NO_AC_NO_ORDER_NO_FAB','master_modified':False,
 'key_advance':'Cached KiCad schematic symbols and standalone library now agree on 17 candidate electrical pin types; previously only an external library-copy proposal. DOES NOT certify pinout or correct hardware.'
}
(ROOT/'E27N_STATIC_AUDIT_RESULTS.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(result,ensure_ascii=False,indent=2))
