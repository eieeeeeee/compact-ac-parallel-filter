import pathlib,csv,json,hashlib,zipfile,io,collections,difflib
P=pathlib.Path('/mnt/data/rc18_e27n');PROJECT=P/'RC18_E27N_KICAD_CANDIDATE_NOT_FAB'
stat=json.loads((P/'E27N_STATIC_AUDIT_RESULTS.json').read_text())
original=pathlib.Path('/mnt/data/rc18_e27m_sources/RC18_E26L_GRID_GEOMETRY_PARITY_NONFAB_HOLD_20261015.zip')
stop=pathlib.Path('/mnt/data/rc18_e27m_sources/E25R_RELEASE_BLOCKERS.csv')
req=pathlib.Path('/mnt/data/rc18_e27m_sources/E25M_REQUIREMENT_TRACEABILITY_MASTER.csv')
with open(stop,encoding='utf-8-sig') as f:blockers=list(csv.DictReader(f))
with open(req,encoding='utf-8-sig') as f:reqs=list(csv.DictReader(f))
assert len(blockers)==17 and len(reqs)==41
assert len(list(csv.DictReader(open(PROJECT/'E26L_MISSING_64_FIT_PARTS.csv',encoding='utf-8-sig'))))==64
for b in blockers:b['release_state']='OPEN';b['candidate_progress']='NO_CHANGE'
# Source column is exact E25R, stage-specific indication is in own columns.
for b in blockers:
 if b['code']=='E25O-SCH':b['candidate_progress']='17 PIN ELECTRICAL TYPE ECO APPLIED TO CACHED SHEET AND LIBRARY; NATIVE ERC UNTESTED'
 if b['code']=='E25R-002':b['candidate_progress']='PRIOR U1003/U1005 STATIC FOOTPRINT CANDIDATES; U1302 UNQUALIFIED; NO VERIFIED FOOTPRINT'
 if b['code']=='E25O-HISTORY':b['candidate_progress']='41 ORIGINAL REQUIREMENTS HASH-VERIFIED AND PRESERVED; FINAL REQUIREMENTS FREEZE NOT DONE'
 if b['code']=='E25R-001':b['candidate_progress']='64 MISSING REFS STATICALLY INVENTORIED; PCB UNMODIFIED'
# categories
names=['PCB FIT AND NET','PHYSICAL SAFETY','CONTROL PERFORMANCE','REQUIREMENTS PROVENANCE','NATIVE TOOL BLOCKER']
categories={
 'PCB FIT AND NET':['E25R-001','E25R-002','E25R-003','E25O-NET','E25O-SCH','E25O-PCB','E25O-FIT','E25O-MFG'],
 'PHYSICAL SAFETY':['E25O-SW','E25O-PGATE','E25O-PV','E25O-PRE','E25O-OCP'],
 'CONTROL PERFORMANCE':['E25O-DSP','E25O-TIME'],
 'REQUIREMENTS PROVENANCE':['E25O-HISTORY'],
 'NATIVE TOOL BLOCKER':['E25R-NATIVE']}
assert {c for s in categories.values() for c in s}=={b['code'] for b in blockers}
catmap={c:g for g,s in categories.items() for c in s}
with (P/'E27N_17_BLOCKER_EXECUTION_REGISTER.csv').open('w',newline='',encoding='utf-8-sig') as f:
 w=csv.writer(f);w.writerow(['number','code','group','original_severity','original_quantity','original_reason','release_state','candidate_progress','next_necessary_evidence'])
 for j,b in enumerate(blockers,1):
  evidence={
   'E25R-001':'Full 64 FIT placed and routed; pad net parity + native DRC',
   'E25R-002':'Manufacturer land pattern, pad pin map and native tests for U1003 U1005 U1302',
   'E25R-003':'Schematic-to-board connectivity comparison after sync',
   'E25O-NET':'KiCad 10 native netlist parity zero',
   'E25O-SCH':'KiCad 10 ERC on candidate with fixed symbol semantics; 0 errors AND inspected warning disposition',
   'E25O-PCB':'KiCad 10 zone-refilled DRC=0 and unconnected=0 on full board',
   'E25O-SW':'Back-to-back switch Q301/Q302 source/drain/gate connection and FMEA',
   'E25O-PGATE':'Remove/review R303 unsafe GPIO gate path after real pin net check',
   'E25O-PV':'Fail-off VGS/time measured and proven across supply loss and all faults',
   'E25O-PRE':'PRE complete physical current/voltage witness, high only when valid, 220 ohm return',
   'E25O-OCP':'L601 independent peak overcurrent detector and switch-level protection test',
   'E25O-DSP':'Full updated S1/HF19 128 corners including alias and modeled actual board',
   'E25O-TIME':'DWT real firmware timing, PWM ADC phase, deadline fault',
   'E25O-FIT':'Final all-FIT 50x40 4layer physical and thermal fit',
   'E25O-MFG':'All verified pads/orderable MPN/BOM/CPL/GERBER parity',
   'E25O-HISTORY':'41 original requirements and 17 blocker final disposition signed off',
   'E25R-NATIVE':'Actual KiCad 10.0.6 runner outputs ERC DRC zone refill parity',
  }
  w.writerow([j,b['code'],catmap[b['code']],b['severity'],b['quantity'],b['reason'],b['release_state'],b['candidate_progress'],evidence[b['code']]])
# Static file diff; only 17 pin type tokens per file. Root maps to E26L originals.
with zipfile.ZipFile(original) as z:
 base='RC18_E26L_GRID_GEOMETRY_NONFAB_HOLD/'
 diffs=[]
 for name in stat['changed_files']:
  before=z.read(base+name).decode('utf-8');after=(PROJECT/name).read_text(encoding='utf-8')
  diffs.append(f'FILE {name}\nBEFORE SHA256 {hashlib.sha256(before.encode()).hexdigest()}\nAFTER SHA256 {hashlib.sha256(after.encode()).hexdigest()}\n')
  # Lines containing all pin attrs can be huge; generate short token patches instead of huge line unified diff.
  for c in csv.DictReader(open(P/'E27N_APPLIED_PIN_TYPES.csv',encoding='utf-8-sig')):
   if c['file']==name:diffs.append(f"  {c['symbol']} pin {c['pin']}: {c['prior_type']} -> {c['candidate_type']}\n")
(P/'E27N_PIN_ATTRIBUTE_CHANGELOG.txt').write_text('\n'.join(diffs),encoding='utf-8')
counts=collections.Counter(catmap.values())
summary='\n'.join(f'- {k}: {counts[k]}' for k in names)
report=f'''# RC18 E27N — KiCad電気ピン属性を実ファイルへ適用した非製造候補

2026-10-15 / **NONFAB HOLD**。原本E26Lは維持し、別フォルダにフルKiCad候補を作成。

## 実際に完了したこと
- 原本E26Lの40件SHA256マニフェストを全数照合。\n- E26Yで提案だけに留まっていた**17ピンの電気属性修正**を、`RC18_E25C.kicad_sym`と実回路図の埋込キャッシュ`11_INDEPENDENT_FAULT_LATCH_E25C.kicad_sch`へ反映。変更は34か所の電気属性トークンだけ。\n- 変更箇所を逆変換すると原本のバイト列に一致。残り38のプロジェクト原本ファイルに変更なし。PCB SHA256 `{stat['pcb_sha256_unchanged']}` 不変。\n- 17全停止条件を出典CSVから再生成し、**0件解除、17件OPEN**と記録。41要件を原本照合。\n- 新プロジェクト内40件のSHA256マニフェスト再生成・全数PASS。

## 変更の意味と限界
- TLV3202 `IC_U1001`: pin 1,7=output / 2,3,5,6=input。
- TPS3431 `IC_U1003`: pin 3,5,6=input / 7,8=open_collector。
- SN74LVC1G74 `IC_U1005`: pin 1,2,6,7=input / 3,5=output。
- これはE26Yでのメーカー資料ベースの提案を**電気属性として同期しただけ**。製造MPN正当性、シンボルpad map、出力pull-up、ERC、実ネットの安全性は保証しない。
- 物理配線の修正、64個未配置の解消、PRE_VERIFIED独立HIGH実回路、U1302足形の確定、回路性能・実機試験は実施していない。

## 17停止条件の重複解消グループ
{summary}

これらは**同一原因に依存する項目を束ねて開発管理するための分類**であり、条件数や技術要件を削除したものではない。

## 次の短い実行順序
1. **Native KiCad10.0.6の実行環境を確保**し、今回候補のERCを走らせ、変更に伴い新たに見える不一致を全件分類。現環境には`kicad-cli`がないため、実行済みと記載してはいけない。
2. **独立PRE_VERIFIED生成元、Q301/Q302ゲート電源断OFF、L601電流保護**の安全要求を優先した回路設計候補を作り、欠陥修正の物理ネットを決める。安全機能同士を安易に単一故障化しない。
3. これが整ってから、**未配置64点/3足形/50×40mm**の実配置と基板ネット整合。保護回路を削って密度を成立させない。
4. 新機能の最新S1/HF19・実過渡・BOM/原価を検証してから全17ゲート解除を判定。

**停止：17 OPEN。NO_POWER / NO_AC / NO_ORDER / NO_FAB。** FROZEN MASTER不変。
'''
(P/'RC18_E27N_BLOCKER_CLOSURE_EXECUTION_REPORT.md').write_text(report,encoding='utf-8')
readme='''RC18 E27N CANDIDATE — NOT FOR FABRICATION / NO POWER / NO AC / NO ORDER
Open RC18_RevB_SI.kicad_pro with native KiCad 10.0.6 in a safe review environment.
Only 17 proposed KiCad electrical pin types were applied to both symbol library and schematic symbol cache.
DO NOT USE LEGACY E26L ERC/DRC REPORTS AS PASS FOR THIS CANDIDATE.
This candidate is NOT cleared: 64 missing FIT; 3 unverified footprints; PRE_VERIFIED independent HIGH producer missing; gate and OCP unsafe; 17 release stops OPEN.
Run current ERC/DRC/netlist and inspect all vendor pad maps before considering any manufacturing.
'''
(PROJECT/'READ_FIRST_E27N_HOLD.txt').write_text(readme)
# Original project 40 members remain manifest-covered; added docs are external to 40-member project manifest.
state={'stage':'E27N','date':'2026-10-15','scope':'17_PIN_TYPE_KICAD_CACHED_AND_LIBRARY_APPLIED_NONFAB','release_blockers_open':17,'release_blockers_closed':0,'requirements':41,'original_source_E26L_sha256':stat['source_zip_sha256'],'E26Y_proposal_sha256':stat['proposal_zip_sha256'],'source_manifest_verified':40,'candidate_manifest_verified':40,'native_kicad':'NOT_RUN_MISSING_CLI','modified_native_files':stat['changed_files'],'physical_PCB_modified':False,'pcb_missing_fit':64,'PRE_VERIFIED':'MISSING_HIGH_GENERATOR','manufacturer_footprints_unknown':['U1003','U1005','U1302'],'latest_s1_hf19':'NOT_RUN','power':'NO_POWER','manufacturing':'HOLD_NO_POWER_NO_AC_NO_ORDER_NO_FAB'}
(P/'RC18_PIPELINE_STATE_E27N_20261015.json').write_text(json.dumps(state,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
handoff='''# RC18 NEXT CHAT HANDOFF E27N — 2026-10-15 NONFAB HOLD

The newest **actual electrical KiCad candidate** is E27N, branched from E26L; source E26L SHA256 64d0a155c2c88bf4d01a892978622d534bc89362bff2ed7aa092f3916f506acc. The E26L/MASTER is UNCHANGED.
- 17 previously proposed symbol pin ELECTRICAL TYPES from E26Y have been applied to BOTH `RC18_E25C.kicad_sym` and cached `lib_symbols` inside `11_INDEPENDENT_FAULT_LATCH_E25C.kicad_sch`.
- 34 token replacements, reversible, both files otherwise bitwise original. 38 unmodified project files and original PCB identical. 40/40 original and 40/40 new manifests verified.
- E27N is NONFAB with original E25R 17 RELEASE STOPS STILL OPEN (zero closed), requirements 41, 64 FIT missing, U1003/U1005/U1302 land patterns not signed off, PRE_VERIFIED HIGH producer missing, Q301/Q302 and branch OCP physical safety unproven.
- Native KiCad 10.0.6 kicad-cli UNAVAILABLE, so ERC/DRC/net parity NOT RUN. There is no basis to claim new PCB PASS.
- Next: obtain native runner, run ERC on E27N, resolve errors; actual safety net ECO for PRE, gate and L601; fully sync 64 placements. No power/AC/order/fab.
'''
(P/'RC18_NEXT_CHAT_HANDOFF_E27N_20261015.md').write_text(handoff,encoding='utf-8')
# Package exactly and include all source files independently for reproducibility.
zip_path=pathlib.Path('/mnt/data/RC18_E27N_KICAD17_PIN_TYPE_CANDIDATE_NONFAB_HOLD_20261015.zip')
with zipfile.ZipFile(zip_path,'w',zipfile.ZIP_DEFLATED,compresslevel=7) as z:
 for p in sorted(PROJECT.rglob('*')):
  if p.is_file():z.write(p,'RC18_E27N_KICAD_CANDIDATE_NOT_FAB/'+str(p.relative_to(PROJECT)))
 for name in ['build_e27n.py','package_e27n.py','E27N_APPLIED_PIN_TYPES.csv','E27N_STATIC_AUDIT_RESULTS.json','E27N_PIN_ATTRIBUTE_CHANGELOG.txt','E27N_17_BLOCKER_EXECUTION_REGISTER.csv','RC18_E27N_BLOCKER_CLOSURE_EXECUTION_REPORT.md','RC18_PIPELINE_STATE_E27N_20261015.json','RC18_NEXT_CHAT_HANDOFF_E27N_20261015.md']:
  z.write(P/name,'REPRO_AND_AUDIT/'+name)
zip_hash=hashlib.sha256(zip_path.read_bytes()).hexdigest()
(P/'E27N_RELEASE_BUNDLE_SHA256.txt').write_text(zip_hash+'  '+zip_path.name+'\n',encoding='utf-8')
with zipfile.ZipFile(zip_path) as z:
 assert z.testzip() is None
print('ARCHIVE',zip_path,zip_path.stat().st_size,zip_hash)
print('BLOCKERS',len(blockers),'CATEGORIES',dict(counts))
