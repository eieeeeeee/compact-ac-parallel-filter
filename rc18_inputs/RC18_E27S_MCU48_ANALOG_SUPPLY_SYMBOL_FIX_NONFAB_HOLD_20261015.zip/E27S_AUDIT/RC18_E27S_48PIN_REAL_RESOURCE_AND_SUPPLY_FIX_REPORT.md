# RC18 E27S — 48ピン実機資源監査とアナログ電源名修正 / NONFAB HOLD

2026-10-15。入力E27RとE27P原本を保全し、**現実のSTM32G474CBT6 LQFP48の48ピン**をE27P子シート03から検出した。STM32G474ファミリー全機能が48ピンで同時利用可能との誤認を避ける。

## 物理ピンの重要な修正（実KiCad編集）

- U1 pin19: 原本名 `VSS` → メーカー名 **`VSSA`**。実接続ネットは **GNDのまま**。
- U1 pin21: 原本名 `VDD` → メーカー名 **`VDDA`**。実接続ネットは **3V3のまま**。
- `03_MCU_DIGITAL.kicad_sch` のキャッシュと `RC18_Custom.kicad_sym` の両方を編集。**合計4箇所のピン名属性**。
- 銅配線・ネット名・BOM・部品座標・フットプリント・IC型番・CPUファームウェアを変更していない。変更は逆変換で原本と一致。未配置64等も未変更。
- アナログレールをVDDA専用に分離する設計を行ったわけではない。3V3/GNDのノイズ、VREF+、ADC/OPAMPアナログ電源、配置を別途検証する。

公式根拠：ST DS12288 Rev 6、LQFP48 4.2、Pin definition Table12 (p.50, 61); https://www.st.com/resource/en/datasheet/stm32g474cb.pdf

## 48ピン実ネットに基づく機能の割当

- **PA8(pin30) SI_HI**: HRTIM1_CHA1 ; **PA9(pin31) SI_LO**: HRTIM1_CHA2。二相PWM物理出力は外付けMOSドライバU6へ接続されたまま。
- **PB13(pin27) VLINE_WIDE_ADC**: ADC3_IN5。
- **PA5(pin13), PA6(pin14), PA7(pin15)**: OPAMP2_VINM / VOUT / VINP。既に専有されているため「未使用の内蔵OPAMPを使って外付けU2削減」は証明されていない。
- **PA1(pin9) ISENSE_ADC_COMP1**: ADC1/2_IN2、COMP1_INP。**PA3(pin11) ISENSE_COMP2**: COMP2_INP。内部比較器は外部独立OCPの代替にはならない。
- **PB0/PB1(pin16/17)**: 12V_MON_ADC / THERM_L601_ADC。
- **PA13/PA14(pin37/38)**: SWDIO/SWCLK予約。**PB8(pin45)** はBOOT0関連。
- `SPARE_*` ラベルが付いているだけで全AFが安全に使えるとは限らない。配線衝突・ADC/OPAMP・AF競合・基板PCB net parityを全数検証する。

## 実時刻制約（理想上限）

- CPU 170MHz・VLINE 2.9090909MS/s → **58.44クロック/標本**。
- PWM補償更新 1.45454545MHz → **116.88クロック/更新**。
- IRQ/AHB/DMA/FM​AC遅延・メモリ競合・ADC同期・ISR実測を差し引く必要がある。現段階では定量的に性能達成を証明できない。

## 簡素化に関する確定判断

既存STM32を1個の書込可能な制御チップとして使う設計方向は有効。今回KiCadで**削除した外付け部品は0**、実証済み削減原価は**0円**。ソフトに物理出力・独立過電流遮断・PRE/失電時OFFを任せない。E27QのU2、U3、U6・MOS・LCの一括削除は同等性未証明。

## 次の検証とHOLD

1. KiCad10.0.6 Native ERC/DRC/zone fill/parityによるこのE27Sピン名修正の確認。
2. STM32CubeMX/STM32CubeIDEによる**48ピン実構成**のAF/OPAMP2/ADC3/HRTIM1/DMA割当エラー検査、FMAC期限測定。
3. PRE_VERIFIED独立生成とHW OCP/失電OFF故障注入を設計、HARD STOP再評価。
4. 削減候補ごとに代替物理機能・実BOM・Native・閉ループ性能を検証。合格前は159FIT/64未配置/3未接続を維持。

**製造停止条件: 既存17項目のうち実行環境1件の技術障害のみ解消、16件は未解除。元E27P/GitHub main/FROZEN MASTERは不変。**

**HOLD_NO_POWER_NO_AC_NO_ORDER_NO_FAB**。絶縁12V低圧研究に限定。
